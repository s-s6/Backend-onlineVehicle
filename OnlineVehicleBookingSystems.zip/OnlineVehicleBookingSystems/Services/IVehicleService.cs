﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Services
{
    public interface IVehicleService
    {
        public List<Vehicle> GetVehicles();
        Vehicle GetVehicle(string id);
        int AddVehicle(Vehicle vehicle);
        int UpdateVehicle(string id, Vehicle vehicle);
        int DeleteVehicle(string id);
        public List<Vehicle> SearchByManufacturersName(string manufacturersName);
        public List<Vehicle> SearchByExShowroomPrice(string exShowroomPrice);
        public List<Vehicle> SearchByColour(string colour);
        public List<Vehicle> SearchBySeatingCapacity(int seatingCapacity);
        public List<Vehicle> SearchByBranchLocation(string branchLocation);
    }
}
