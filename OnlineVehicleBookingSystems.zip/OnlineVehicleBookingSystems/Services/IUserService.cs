﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Services
{
    public interface IUserService
    {
        public List<User> GetUsers();
        User GetUser(string id);
        int AddUser(User user);
        int UpdateUser(string id, User user);
        int DeleteUser(string id);
        string Login(string userId, string password);
    }
}
