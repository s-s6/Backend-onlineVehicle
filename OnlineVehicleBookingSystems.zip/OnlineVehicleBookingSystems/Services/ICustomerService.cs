﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Services
{
    public interface ICustomerService
    {
        public List<Customer> GetCustomers();
        Customer GetCustomer(int id);
        int AddCustomer(Customer customer);
        int UpdateCustomer(int id, Customer customer);
        int DeleteCustomer(int id);
    }
}
