﻿using OnlineVehicleBookingSystems.Exceptions;
using OnlineVehicleBookingSystems.Models;
using OnlineVehicleBookingSystems.Repositories;

namespace OnlineVehicleBookingSystems.Services
{
    public class AdminService : IAdminService
    {
        private readonly IAdminRepository repo;
        public AdminService(IAdminRepository repo)
        {
            this.repo = repo;
        }
        public List<Admin> GetAdmins()
        {
            return repo.GetAdmins();
        }
        public int AddAdmin(Admin admin)
        {
            if (repo.GetAdmin(admin.AdminID) != null)
            {
                throw new AdminAlreadyExistsException($"Admin with Admin id {admin.AdminID} already exists");
            }
            return repo.AddAdmin(admin);
        }


        public int DeleteAdmin(int id)
        {
            if (repo.GetAdmin(id) == null)
            {
                throw new AdminNotFoundException($"Admin with Admin id {id} does not exists");
            }
            return repo.DeleteAdmin(id);
        }
        public Admin GetAdmin(int id)
        {
            Admin c = repo.GetAdmin(id);
            if (c == null)
            {
                throw new AdminNotFoundException($"Admin with Admin id {id} does not exists");
            }
            return c;
        }
        public int UpdateAdmin(int id, Admin admin)
        {
            if (repo.GetAdmin(id) == null)
            {
                throw new AdminNotFoundException($"Admin with Admin id {id} does not exists");
            }
            return repo.UpdateAdmin(id, admin);
        }

    }
}
