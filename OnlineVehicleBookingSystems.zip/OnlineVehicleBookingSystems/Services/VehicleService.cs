﻿using OnlineVehicleBookingSystems.Exceptions;
using OnlineVehicleBookingSystems.Models;
using OnlineVehicleBookingSystems.Repositories;

namespace OnlineVehicleBookingSystems.Services
{
    public class VehicleService : IVehicleService
    {
        private readonly IVehicleRepository repo;
        public VehicleService(IVehicleRepository repo)
        {
            this.repo = repo;
        }
        public List<Vehicle> GetVehicles()
        {
            return repo.GetVehicles();
        }
        public int AddVehicle(Vehicle vehicle)
        {
            if (repo.GetVehicle(vehicle.VehicleCode) != null)
            {
                throw new VehicleAlreadyExistsException($"Vehicle with Vehicle Code {vehicle.VehicleCode} already exists");
            }
            return repo.AddVehicle(vehicle);
        }


        public int DeleteVehicle(string id)
        {
            if (repo.GetVehicle(id) == null)
            {
                throw new VehicleNotFoundException($"Vehicle with Vehicle Code {id} does not exists");
            }
            return repo.DeleteVehicle(id);
        }
        public Vehicle GetVehicle(string id)
        {
            Vehicle c = repo.GetVehicle(id);
            if (c == null)
            {
                throw new VehicleNotFoundException($"Vehicle with Vehicle Code {id} does not exists");
            }
            return c;
        }
        public int UpdateVehicle(string id, Vehicle vehicle)
        {
            if (repo.GetVehicle(id) == null)
            {
                throw new VehicleNotFoundException($"Vehicle with Vehicle Code {id} does not exists");
            }
            return repo.UpdateVehicle(id, vehicle);
        }
        public List<Vehicle> SearchByManufacturersName(string manufacturersName)
        {
            return repo.SearchByManufacturersName(manufacturersName);
        }
        public List<Vehicle> SearchByExShowroomPrice(string exShowroomPrice)
        {
            return repo.SearchByExShowroomPrice(exShowroomPrice);
        }
        public List<Vehicle> SearchByColour(string colour)
        {
            return repo.SearchByColour(colour);
        }
        public List<Vehicle> SearchBySeatingCapacity(int seatingCapacity)
        {
            return repo.SearchBySeatingCapacity(seatingCapacity);
        }
        public List<Vehicle> SearchByBranchLocation(string branchLocation)
        {
            return repo.SearchByBranchLocation(branchLocation);
        }
    }
}
