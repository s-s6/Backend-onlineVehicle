﻿using OnlineVehicleBookingSystems.Exceptions;
using OnlineVehicleBookingSystems.Models;
using OnlineVehicleBookingSystems.Repositories;

namespace OnlineVehicleBookingSystems.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository repo;
        public CustomerService(ICustomerRepository repo)
        {
            this.repo = repo;
        }
        public List<Customer> GetCustomers()
        {
            return repo.GetCustomers();
        }
        public int AddCustomer(Customer customer)
        {
            if (repo.GetCustomer(customer.CustomerID) != null)
            {
                throw new CustomerAlreadyExistsException($"Customer with Customer id {customer.CustomerID} already exists");
            }
            return repo.AddCustomer(customer);
        }


        public int DeleteCustomer(int id)
        {
            if (repo.GetCustomer(id) == null)
            {
                throw new CustomerNotFoundException($"Customer with Customer id {id} does not exists");
            }
            return repo.DeleteCustomer(id);
        }
        public Customer GetCustomer(int id)
        {
            Customer c = repo.GetCustomer(id);
            if (c == null)
            {
                throw new CustomerNotFoundException($"Customer with Customer id {id} does not exists");
            }
            return c;
        }
        public int UpdateCustomer(int id, Customer customer)
        {
            if (repo.GetCustomer(id) == null)
            {
                throw new CustomerNotFoundException($"Customer with Customer id {id} does not exists");
            }
            return repo.UpdateCustomer(id, customer);
        }
    }
}
