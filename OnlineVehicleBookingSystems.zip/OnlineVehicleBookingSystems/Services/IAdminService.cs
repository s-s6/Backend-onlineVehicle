﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Services
{
    public interface IAdminService
    {
        public List<Admin> GetAdmins();
        Admin GetAdmin(int id);
        int AddAdmin(Admin admin);
        int UpdateAdmin(int id, Admin admin);
        int DeleteAdmin(int id);
    }
}
