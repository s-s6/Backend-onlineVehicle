﻿using OnlineVehicleBookingSystems.Exceptions;
using OnlineVehicleBookingSystems.Models;
using OnlineVehicleBookingSystems.Repositories;

namespace OnlineVehicleBookingSystems.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository repo;
        public UserService(IUserRepository repo)
        {
            this.repo = repo;
        }
        public List<User> GetUsers()
        {
            return repo.GetUsers();
        }
        public int AddUser(User user)
        {
            if (repo.GetUser(user.UserID) != null)
            {
                throw new UserAlreadyExistsException($"User with User id {user.UserID} already exists");
            }
            return repo.AddUser(user);
        }


        public int DeleteUser(string id)
        {
            if (repo.GetUser(id) == null)
            {
                throw new UserNotFoundException($"User with User id {id} does not exists");
            }
            return repo.DeleteUser(id);
        }
        public User GetUser(string id)
        {
            User c = repo.GetUser(id);
            if (c == null)
            {
                throw new UserNotFoundException($"User with User id {id} does not exists");
            }
            return c;
        }
        public int UpdateUser(string id, User user)
        {
            if (repo.GetUser(id) == null)
            {
                throw new UserNotFoundException($"User with User id {id} does not exists");
            }
            return repo.UpdateUser(id, user);
        }
        public string Login(string userId,string password)
        {
            return repo.Login(userId,password);
        }
    }
}
