﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Services
{
    public interface IBookingService
    {
        public List<Booking> GetBookings();
        Booking GetBooking(int id);
        int AddBooking(Booking booking);
        int UpdateBooking(int id, Booking booking);
        int DeleteBooking(int id);
    }
}
