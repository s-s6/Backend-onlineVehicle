﻿using OnlineVehicleBookingSystems.Exceptions;
using OnlineVehicleBookingSystems.Models;
using OnlineVehicleBookingSystems.Repositories;

namespace OnlineVehicleBookingSystems.Services
{
    public class BookingService : IBookingService
    {
        private readonly IBookingRepository repo;
        public BookingService(IBookingRepository repo)
        {
            this.repo = repo;
        }
        public List<Booking> GetBookings()
        {
            return repo.GetBookings();
        }
        public int AddBooking(Booking booking)
        {
            if (repo.GetBooking(booking.BookingID) != null)
            {
                throw new BookingAlreadyExistsException($"Booking with Booking id {booking.BookingID} already exists");
            }
            return repo.AddBooking(booking);
        }


        public int DeleteBooking(int id)
        {
            if (repo.GetBooking(id) == null)
            {
                throw new BookingNotFoundException($"Booking with Booking id {id} does not exists");
            }
            return repo.DeleteBooking(id);
        }
        public Booking GetBooking(int id)
        {
            Booking c = repo.GetBooking(id);
            if (c == null)
            {
                throw new BookingNotFoundException($"Booking with Booking id {id} does not exists");
            }
            return c;
        }
        public int UpdateBooking(int id, Booking booking)
        {
            if (repo.GetBooking(id) == null)
            {
                throw new BookingNotFoundException($"Booking with Booking id {id} does not exists");
            }
            return repo.UpdateBooking(id, booking);
        }
        
    }
}
