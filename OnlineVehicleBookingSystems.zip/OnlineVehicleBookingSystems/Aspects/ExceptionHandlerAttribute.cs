﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using OnlineVehicleBookingSystems.Exceptions;

namespace OnlineVehicleBookingSystems.Aspects
{
    public class ExceptionHandlerAttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            var exceptionType = context.Exception.GetType();
            var message = context.Exception.Message;

            if (exceptionType == typeof(UserNotFoundException) || exceptionType == typeof(AdminNotFoundException) || exceptionType == typeof(CustomerNotFoundException) || exceptionType == typeof(VehicleNotFoundException) || exceptionType == typeof(BookingNotFoundException))
            {
                var result = new NotFoundObjectResult(message);
                context.Result = result;
            }
            else if (exceptionType == typeof(UserAlreadyExistsException) || exceptionType == typeof(AdminAlreadyExistsException) || exceptionType == typeof(CustomerAlreadyExistsException) || exceptionType == typeof(VehicleAlreadyExistsException) || exceptionType == typeof(BookingAlreadyExistsException))
            {
                var result = new ConflictObjectResult(message);
                context.Result = result;
            }
            else
            {
                var result = new StatusCodeResult(500);
                context.Result = result;
            }
        }
    }
}
