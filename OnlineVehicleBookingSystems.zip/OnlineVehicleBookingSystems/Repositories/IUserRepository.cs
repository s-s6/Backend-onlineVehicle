﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Repositories
{
    public interface IUserRepository
    {
        List<User> GetUsers();
        User GetUser(string id);
        int AddUser(User user);
        int UpdateUser(string id, User user);
        int DeleteUser(string id);
        //string GenerateJwtToken(User user, IConfiguration configuration);
        string Login(string UserID, string password);
    }
}
