﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Repositories
{
    public interface ICustomerRepository
    {
        List<Customer> GetCustomers();

        Customer GetCustomer(int id);
        int AddCustomer(Customer customer);
        int UpdateCustomer(int id,Customer customer);
        int DeleteCustomer(int id);

    }
}
