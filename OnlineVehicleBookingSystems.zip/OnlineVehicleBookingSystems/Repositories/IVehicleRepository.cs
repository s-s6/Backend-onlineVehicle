﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Repositories
{
    public interface IVehicleRepository
    {
        List<Vehicle> GetVehicles();
        Vehicle GetVehicle(string id);
        int AddVehicle(Vehicle vehicle);
        int UpdateVehicle(string id,Vehicle vehicle);
        int DeleteVehicle(string id);
        List<Vehicle> SearchByManufacturersName(string manufacturersName);
        List<Vehicle> SearchByExShowroomPrice(string exShowroomPrice);
        List<Vehicle> SearchByColour(string colour);
        List<Vehicle> SearchBySeatingCapacity(int seatingCapacity);
        List<Vehicle> SearchByBranchLocation(string branchLocation);

    }
}
