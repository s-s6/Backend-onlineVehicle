﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly VehicleBookingDbContext db;

        public CustomerRepository(VehicleBookingDbContext db, IConfiguration configuration)
        {
            this.db = db;
           
        }

        public List<Customer> GetCustomers()
        {
            return db.Customers.ToList();
        }

        public int AddCustomer(Customer customer)
        {
            db.Customers.Add(customer);
            return db.SaveChanges();
        }

        public int DeleteCustomer(int id)
        {
            Customer c = db.Customers.Where(x => x.CustomerID == id).FirstOrDefault();
            db.Customers.Remove(c);
            return db.SaveChanges();
        }

        public Customer GetCustomer(int id)
        {
            return db.Customers.Where(x => x.CustomerID == id).FirstOrDefault();
        }

        public int UpdateCustomer(int id, Customer customer)
        {
            Customer c = db.Customers.Where(x => x.CustomerID == id).FirstOrDefault();
            c.LoginID = customer.LoginID;
            c.CustomerName = customer.CustomerName;
            c.Address = customer.Address;
            c.EmailId = customer.EmailId;
            c.PhoneNumber = customer.PhoneNumber;
            c.Occupation = customer.Occupation;
            db.Entry<Customer>(c).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            return db.SaveChanges();
        }

    }

}
