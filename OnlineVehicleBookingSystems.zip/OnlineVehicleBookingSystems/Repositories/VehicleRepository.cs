﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Repositories
{
    public class VehicleRepository : IVehicleRepository
    {
        private readonly VehicleBookingDbContext db;

        public VehicleRepository(VehicleBookingDbContext db)
        {
            this.db = db;
        }

        public List<Vehicle> GetVehicles()
        {
            return db.Vehicles.ToList();
        }

        public int AddVehicle(Vehicle vehicle)
        {
            db.Vehicles.Add(vehicle);
            return db.SaveChanges();
        }

        public int DeleteVehicle(string id)
        {
            Vehicle c = db.Vehicles.Where(x => x.VehicleCode == id).FirstOrDefault();
            db.Vehicles.Remove(c);
            return db.SaveChanges();
        }
        public Vehicle GetVehicle(string id)
        {
            return db.Vehicles.Where(x => x.VehicleCode == id).FirstOrDefault();
        }
        public int UpdateVehicle(string id, Vehicle vehicle)
        {
            Vehicle c = db.Vehicles.Where(x => x.VehicleCode == id).FirstOrDefault();
            c.BranchLocation = vehicle.BranchLocation;
            c.ManufacturersName = vehicle.ManufacturersName;
            c.ExShowroomPrice = vehicle.ExShowroomPrice;
            c.Colour = vehicle.Colour;
            c.NoVehiclesAvailable = vehicle.NoVehiclesAvailable;
            c.SeatingCapacity = vehicle.SeatingCapacity;
            c.StockLastsTill = vehicle.StockLastsTill;
            db.Entry<Vehicle>(c).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            return db.SaveChanges();
        }

        public List<Vehicle> SearchByManufacturersName(string manufacturersName)
        {
            string sqlQuery = "EXEC SearchByManufacturersName @ManufacturersName";
            var parameter = new SqlParameter("@ManufacturersName", manufacturersName);

            return db.Vehicles.FromSqlRaw(sqlQuery, parameter).ToList();
        }

        public List<Vehicle> SearchByExShowroomPrice(string exShowroomPrice)
        {
            string sqlQuery = "EXEC SearchByExShowroomPrice @ExShowroomPrice";
            var parameter = new SqlParameter("@ExShowroomPrice", exShowroomPrice);

            return db.Vehicles.FromSqlRaw(sqlQuery, parameter).ToList();
        }

        public List<Vehicle> SearchByColour(string colour)
        {
            string sqlQuery = "EXEC SearchByColour @Colour";
            var parameter = new SqlParameter("@Colour", colour);

            return db.Vehicles.FromSqlRaw(sqlQuery, parameter).ToList();
        }

        public List<Vehicle> SearchBySeatingCapacity(int seatingCapacity)
        {
            var matchingVehicles = from vehicle in db.Vehicles
                                   where vehicle.SeatingCapacity == seatingCapacity
                                   select vehicle;
            return matchingVehicles.ToList();
        }

        public List<Vehicle> SearchByBranchLocation(string branchLocation)
        {
            string sqlQuery = "EXEC SearchByBranchLocation @BranchLocation";
            var parameter = new SqlParameter("@BranchLocation", branchLocation);

            return db.Vehicles.FromSqlRaw(sqlQuery, parameter).ToList();
        }
    }
}
