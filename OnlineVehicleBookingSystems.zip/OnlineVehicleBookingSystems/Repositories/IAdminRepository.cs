﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Repositories
{
    public interface IAdminRepository
    {
        List<Admin> GetAdmins();
        Admin GetAdmin(int id);
        int AddAdmin(Admin Admin);
        int UpdateAdmin(int id, Admin admin);
        int DeleteAdmin(int id);

    }
}
