﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Repositories
{
    public class BookingRepository : IBookingRepository
    {
        private readonly VehicleBookingDbContext db;

        public BookingRepository(VehicleBookingDbContext db)
        {
            this.db = db;

        }

        public List<Booking> GetBookings()
        {
            return db.Bookings.ToList();
        }

        public int AddBooking(Booking booking)
        {
            db.Bookings.Add(booking);
            return db.SaveChanges();
        }

        public int DeleteBooking(int id)
        {
            Booking c = db.Bookings.Where(x => x.BookingID == id).FirstOrDefault();
            db.Bookings.Remove(c);
            return db.SaveChanges();
        }

        public Booking GetBooking(int id) 
        {
            return db.Bookings.Where(x => x.BookingID == id).FirstOrDefault();
        }

        public int UpdateBooking(int id,Booking booking)
        {
            Booking c = db.Bookings.Where(x => x.BookingID == id).FirstOrDefault();
            c.ManufacturerCode = booking.ManufacturerCode;
            c.VehicleCode = booking.VehicleCode;
            c.StockLastsTill = booking.StockLastsTill;
            c.BookingConfirmationStatus = booking.BookingConfirmationStatus;    
            c.Comments = booking.Comments;
            c.BranchLocation = booking.BranchLocation;
            c.BookingConfirmationStatus = booking.BookingConfirmationStatus;
            db.Entry<Booking>(c).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            return db.SaveChanges();

        }
    }
}
