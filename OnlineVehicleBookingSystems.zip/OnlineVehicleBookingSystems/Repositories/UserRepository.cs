﻿using Microsoft.IdentityModel.Tokens;
using OnlineVehicleBookingSystems.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace OnlineVehicleBookingSystems.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly VehicleBookingDbContext db;
        private IConfiguration _configuration;

        public UserRepository(VehicleBookingDbContext db,IConfiguration configuration)
        {
            this.db = db;
            this._configuration = configuration;
        }

        public List<User> GetUsers()
        {
            return db.Users.ToList();
        }

        public int AddUser(User user)
        {
            db.Users.Add(user);
            return db.SaveChanges();
        }

        public int DeleteUser(string id)
        {
            //string idString = id.ToString();
            User c = db.Users.Where(x => x.UserID == id).FirstOrDefault();
            db.Users.Remove(c);
            return db.SaveChanges();
        }

        public User GetUser(string id)
        {
            //string idString = id.ToString();
            return db.Users.Where(x => x.UserID == id).FirstOrDefault();
        }

        public int UpdateUser(string id, User user)
        {
            //string idString = id.ToString();
            User c = db.Users.Where(x => x.UserID == id).FirstOrDefault();
            c.Password = user.Password;
            c.Role = user.Role;
            db.Entry<User>(c).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            return db.SaveChanges();
        }

         public string Login(string userId, string password)
         {
             var userExist = db.Users.FirstOrDefault(t => t.UserID == userId && t.Password == password);
             if (userExist != null)
             {
                 var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                 var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
                 var claims = new[]
                 {
                     new Claim("UserId",userExist.UserID),
                     new Claim("Role",userExist.Role),
                     //new Claim("CreatedDate", userExist.CreatedDate.ToString("o"))
                 };
                 var token = new JwtSecurityToken(_configuration["Jwt:Issuer"], _configuration["Jwt:Audience"], claims, expires: DateTime.Now.AddMinutes(30), signingCredentials: credentials);
                 return new JwtSecurityTokenHandler().WriteToken(token);
             }
             return null;
         }

       /* public string GenerateJwtToken(User user, IConfiguration configuration)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                 new Claim("UserID", user.UserID),
                 new Claim("Role", user.Role),
                 new Claim("CreatedDate", user.CreatedDate.ToString("o")) 
            };

            var token = new JwtSecurityToken(
                configuration["Jwt:Issuer"],
                configuration["Jwt:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }*/

    }
}
