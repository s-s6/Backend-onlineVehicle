﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Repositories
{
    public interface IBookingRepository
    {
        List<Booking> GetBookings();
        Booking GetBooking(int id);
        int AddBooking(Booking booking);
        int UpdateBooking(int id,Booking booking);
        int DeleteBooking(int id);

    }
}
