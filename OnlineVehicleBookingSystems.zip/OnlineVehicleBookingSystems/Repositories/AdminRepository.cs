﻿using OnlineVehicleBookingSystems.Models;

namespace OnlineVehicleBookingSystems.Repositories
{
    public class AdminRepository : IAdminRepository
    {
        private readonly VehicleBookingDbContext db;

        public AdminRepository(VehicleBookingDbContext db)
        {
            this.db = db;
        }

        public List<Admin> GetAdmins()
        {
            return db.Admins.ToList();
        }
        public int AddAdmin(Admin admin)
        {
            db.Admins.Add(admin);
            return db.SaveChanges();
        }
        public int DeleteAdmin(int id)
        {
            Admin c = db.Admins.Where(x => x.AdminID == id).FirstOrDefault();
            db.Admins.Remove(c);
            return db.SaveChanges();
        }
        public Admin GetAdmin(int id)
        {
            return db.Admins.Where(x => x.AdminID == id).FirstOrDefault();
        }

        public int UpdateAdmin(int id, Admin admin)
        {
            Admin c = db.Admins.Where(x =>x.AdminID == id).FirstOrDefault();
            c.LoginID = admin.LoginID;
            c.AdminName = admin.AdminName;
            c.BranchLocation = admin.BranchLocation;
            c.Address = admin.Address;
            c.EmailID = admin.EmailID;
            c.PhoneNumber = admin.PhoneNumber;
            db.Entry<Admin>(c).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            return db.SaveChanges();
        }
    }

}
