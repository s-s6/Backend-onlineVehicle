﻿namespace OnlineVehicleBookingSystems.Exceptions
{
    public class AdminNotFoundException : ApplicationException
    {
        public AdminNotFoundException() { }
        public AdminNotFoundException(string msg) : base(msg) { }
    }
}
