﻿namespace OnlineVehicleBookingSystems.Exceptions
{
    public class VehicleNotFoundException : ApplicationException
    {
        public VehicleNotFoundException() { }
        public VehicleNotFoundException(string msg) : base(msg) { }
    }
}
