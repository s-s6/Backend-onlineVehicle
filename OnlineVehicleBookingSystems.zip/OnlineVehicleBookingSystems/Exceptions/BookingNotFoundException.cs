﻿namespace OnlineVehicleBookingSystems.Exceptions
{
    public class BookingNotFoundException : ApplicationException
    {
        public BookingNotFoundException() { }
        public BookingNotFoundException(string msg) : base(msg) { }
    }
}
