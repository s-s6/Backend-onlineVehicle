﻿namespace OnlineVehicleBookingSystems.Exceptions
{
    public class BookingAlreadyExistsException : ApplicationException
    {
        public BookingAlreadyExistsException() { }
        public BookingAlreadyExistsException(string msg) : base(msg) { }
    }
}
