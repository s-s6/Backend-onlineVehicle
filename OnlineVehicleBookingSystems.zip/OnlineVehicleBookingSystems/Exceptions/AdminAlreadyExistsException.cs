﻿namespace OnlineVehicleBookingSystems.Exceptions
{
    public class AdminAlreadyExistsException : ApplicationException
    {
        public AdminAlreadyExistsException() { }
        public AdminAlreadyExistsException(string msg) : base(msg) { }
    }
}
