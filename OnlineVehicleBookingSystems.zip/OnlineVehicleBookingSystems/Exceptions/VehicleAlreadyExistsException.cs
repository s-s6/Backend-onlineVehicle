﻿namespace OnlineVehicleBookingSystems.Exceptions
{
    public class VehicleAlreadyExistsException : ApplicationException
    {
        public VehicleAlreadyExistsException() { }
        public VehicleAlreadyExistsException(string msg) : base(msg) { }
    }
}
