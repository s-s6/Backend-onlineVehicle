﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using OnlineVehicleBookingSystems.Aspects;
using OnlineVehicleBookingSystems.Models;
using OnlineVehicleBookingSystems.Services;

namespace OnlineVehicleBookingSystems.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    [EnableCors("policy")]
    public class VehicleController : ControllerBase
    {
        private readonly IVehicleService service;

        public VehicleController(IVehicleService service)
        {
            this.service = service;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(service.GetVehicles());
        }


        [HttpGet]
        [Route("{id}")]
        public IActionResult Get(string id)
        {
            return Ok(service.GetVehicle(id));
        }



        [HttpPost]
        public IActionResult Post(Vehicle vehicle)
        {
            return StatusCode(201, service.AddVehicle(vehicle));
        }



        [HttpPut]
        [Route("{id}")]
        public IActionResult Put(string id, Vehicle vehicle)
        {
            return Ok(service.UpdateVehicle(id, vehicle));
        }


        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete(string id)
        {
            return Ok(service.DeleteVehicle(id));
        }

        [HttpGet]
        [Route("{manufacturersName}/SearchByManufacturersName")]
        public IActionResult GetbyManufacturersName(string manufacturersName)
        {
            return Ok(service.SearchByManufacturersName(manufacturersName));
        }
        [HttpGet]
        [Route("{exShowroomPrice}/SearchByExShowroomPrice")]
        public IActionResult GetbyExShowroomPrice(string exShowroomPrice)
        {
            return Ok(service.SearchByExShowroomPrice(exShowroomPrice));
        }

        [HttpGet]
        [Route("{colour}/SearchByColour")]
        public IActionResult GetByColour(string colour)
        {
            return Ok(service.SearchByColour(colour));
        }

        [HttpGet]
        [Route("{SeatingCapacity}/SearchBySeatingCapacity")]
        public IActionResult GetBySeatingCapacity(int seatingCapacity)
        {
            return Ok(service.SearchBySeatingCapacity(seatingCapacity));
        }

        [HttpGet]
        [Route("{branchLocation}/SearchByBranchLocation")]
        public IActionResult GetByBranchLocation(string branchLocation)
        {
            return Ok(service.SearchByBranchLocation(branchLocation));
        }
    }
}
