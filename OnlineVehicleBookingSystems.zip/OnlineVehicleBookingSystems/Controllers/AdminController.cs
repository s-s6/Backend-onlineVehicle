﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using OnlineVehicleBookingSystems.Aspects;
using OnlineVehicleBookingSystems.Models;
using OnlineVehicleBookingSystems.Services;

namespace OnlineVehicleBookingSystems.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    [EnableCors("policy")]
    public class AdminController : ControllerBase
    {
        private readonly IAdminService service;

        public AdminController(IAdminService service)
        {
            this.service = service;
        }
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(service.GetAdmins());
        }

        [HttpGet]
        [Route("{id}")]
        public IActionResult Get(int id)
        {
            return Ok(service.GetAdmin(id));
        }

        [HttpPost]
        public IActionResult Post(Admin admin)
        {
            return StatusCode(201, service.AddAdmin(admin));
        }



        [HttpPut]
        [Route("{id}")]
        public IActionResult Put(int id, Admin admin)
        {
            return Ok(service.UpdateAdmin(id, admin));
        }


        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete(int id)
        {
            return Ok(service.DeleteAdmin(id));
        }
    }

    
}
