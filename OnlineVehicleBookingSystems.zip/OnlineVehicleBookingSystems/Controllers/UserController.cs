﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using OnlineVehicleBookingSystems.Aspects;
using OnlineVehicleBookingSystems.Models;
using OnlineVehicleBookingSystems.Services;

namespace OnlineVehicleBookingSystems.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    [EnableCors("policy")]
    public class UserController : ControllerBase
    {
        private readonly IUserService service;

        public UserController(IUserService service)
        {
            this.service = service;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(service.GetUsers());
        }


        [HttpGet]
        [Route("{id}")]
        public IActionResult Get(string id)
        {
            return Ok(service.GetUser(id));
        }



        [HttpPost]
        public IActionResult Post(User user)
        {
            return StatusCode(201, service.AddUser(user));
        }



        [HttpPut]
        [Route("{id}")]
        public IActionResult Put(string id, User user)
        {
            return Ok(service.UpdateUser(id, user));
        }


        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete(string id)
        {
            return Ok(service.DeleteUser(id));
        }

        [HttpPost("login")]
        public string UserLogin(string UserID, string password)
        {
            var result = service.Login(UserID, password);

            if (result != null)
            {
                return result;
            }
            return null;
        }

        
    }
}
