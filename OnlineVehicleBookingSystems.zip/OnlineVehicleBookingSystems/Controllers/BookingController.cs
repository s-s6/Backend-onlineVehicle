﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using OnlineVehicleBookingSystems.Aspects;
using OnlineVehicleBookingSystems.Models;
using OnlineVehicleBookingSystems.Services;

namespace OnlineVehicleBookingSystems.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    [EnableCors("policy")]
    public class BookingController : ControllerBase
    {
        private readonly IBookingService service;

        public BookingController(IBookingService service)
        {
            this.service = service;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(service.GetBookings());
        }


        [HttpGet]
        [Route("{id}")]
        public IActionResult Get(int id)
        {
            return Ok(service.GetBooking(id));
        }



        [HttpPost]
        public IActionResult Post(Booking booking)
        {
            return StatusCode(201, service.AddBooking(booking));
        }



        [HttpPut]
        [Route("{id}")]
        public IActionResult Put(int id, Booking booking)
        {
            return Ok(service.UpdateBooking(id, booking));
        }


        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete(int id)
        {
            return Ok(service.DeleteBooking(id));
        }
    }
}
