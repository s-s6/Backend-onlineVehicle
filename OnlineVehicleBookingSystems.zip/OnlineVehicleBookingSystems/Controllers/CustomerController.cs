﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using OnlineVehicleBookingSystems.Aspects;
using OnlineVehicleBookingSystems.Models;
using OnlineVehicleBookingSystems.Services;

namespace OnlineVehicleBookingSystems.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    [EnableCors("policy")]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerService service;

        public CustomerController(ICustomerService service)
        {
            this.service = service;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(service.GetCustomers());
        }


        [HttpGet]
        [Route("{id}")]
        public IActionResult Get(int id)
        {
            return Ok(service.GetCustomer(id));
        }



        [HttpPost]
        public IActionResult Post(Customer customer)
        {
            return StatusCode(201, service.AddCustomer(customer));
        }



        [HttpPut]
        [Route("{id}")]
        public IActionResult Put(int id, Customer customer)
        {
            return Ok(service.UpdateCustomer(id, customer));
        }


        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete(int id)
        {
            return Ok(service.DeleteCustomer(id));
        }
    }
}
