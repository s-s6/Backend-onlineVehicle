﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineVehicleBookingSystems.Models
{
    public class Booking
    {
        [Key]
        public int BookingID { get; set; }

        [ForeignKey("CustomerLoginID")]
        public string CustomerLoginID { get; set; }

        [ForeignKey("VehicleCode")]
        public string VehicleCode { get; set; }

        public string ManufacturerCode { get; set; }

        public DateTime StockLastsTill { get; set; }

        public char BookingConfirmationStatus { get; set; } = 'N';

        public string BranchLocation { get; set; }

        public string Comments { get; set; }
    }
}
