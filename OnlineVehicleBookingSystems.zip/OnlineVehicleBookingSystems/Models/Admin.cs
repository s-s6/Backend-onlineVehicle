﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineVehicleBookingSystems.Models
{
    public class Admin
    {
        [Key]
        public int AdminID { get; set; }

        [ForeignKey("LoginID")]
        public string LoginID { get; set; }

        public string AdminName { get; set; }

        public string BranchLocation { get; set; }

        public string Address { get; set; }

        public string EmailID { get; set; }

        public string PhoneNumber { get; set; }

    }
}
