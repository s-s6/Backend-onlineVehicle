﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
namespace OnlineVehicleBookingSystems.Models
{
    public class Vehicle
    {
        [Key]
        public string VehicleCode { get; set; }

        [StringLength(30)]
        public string BranchLocation { get; set; }

        public string ManufacturersName { get; set; }

        public string ExShowroomPrice { get; set; }

        public string Colour { get; set; }

        public int NoVehiclesAvailable { get; set; }

        public int SeatingCapacity { get; set; }

        public DateTime StockLastsTill { get; set; }


    }
}