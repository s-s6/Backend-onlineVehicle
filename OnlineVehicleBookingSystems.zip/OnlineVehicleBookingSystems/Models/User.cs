﻿using System.ComponentModel.DataAnnotations;

namespace OnlineVehicleBookingSystems.Models
{
    public class User
    {
        [Key]
        [Required]
        public string UserID { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string Role { get; set; }
        [Required]
        public DateTime CreatedDate { get; set; }
    }
}
