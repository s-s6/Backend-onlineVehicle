﻿using Microsoft.EntityFrameworkCore;

namespace OnlineVehicleBookingSystems.Models
{
    public class VehicleBookingDbContext : DbContext
    {
        public VehicleBookingDbContext(DbContextOptions<VehicleBookingDbContext> options) : base(options) { }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Vehicle> Vehicles { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Vehicle>()
                .HasAlternateKey(v => v.BranchLocation)
                .HasName("AlternateKey_BranchLocation");

            base.OnModelCreating(modelBuilder);
        }
    }
}
